package barracksWars.models.units;

public class Magician extends AbstractUnit{
    public Magician() {
        super(100, 100);
    }
}
